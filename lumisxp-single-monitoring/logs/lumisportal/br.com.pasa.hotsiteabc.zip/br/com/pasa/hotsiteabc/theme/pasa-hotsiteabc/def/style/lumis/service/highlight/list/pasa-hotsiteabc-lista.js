<h1 class="section-header">Funcionalidades</h1> 
<%
var rows = lum_xpath.getMaps("//data/row");
for(var i in rows)
{
	var row = rows[i];
%>
	<article class="highlights-list-item all-full"> 
	    <div class="desktop-6 tablet-3 mobile-full news-image"> 
	        <img src="<%=row.image.href%>" /> 
	    </div> 
	    <div class="desktop-6 tablet-3 mobile-full news-content"> 
	        <h1><%=row.title%></h1> 
	        <p><%=row.content%></p> 
	    </div> 
	</article> 
	
<%
}
%>
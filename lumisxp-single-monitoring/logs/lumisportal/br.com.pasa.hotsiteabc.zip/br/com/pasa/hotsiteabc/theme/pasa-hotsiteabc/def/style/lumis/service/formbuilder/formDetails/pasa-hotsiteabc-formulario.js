<h1 class="section-header">Entre em contato com a gente.</h1> 
<article class="news-detail desktop-8 desktop-push-2 tablet-full mobile-full"> 
    <p class="intro">Preencha o formulário abaixo. Todos os campos são obrigatórios.</p> 
    <div class="row warning"> 
        <p class="all-full success" style="display:none">Sua mensagem foi enviada com sucesso!</p> 
        <p class="all-full error" style="display:none">Houveram erros na hora de enviar sua mensagem.</p> 
    </div> 
    <div class="row form"> 
        <form id="myForm" method="post" action="<%=lum_xpath.valueOf("//control[@type='lum_form']/data/action-commit", lum_document)%>"> 
            <div class="desktop-5 tablet-3 mobile-full"> 
                <label>Nome:</label> 
                <input name="nome" type="text" class="input" /> 
            </div> 
            <div class="desktop-5 tablet-3 mobile-full"> 
                <label>E-mail:</label> 
                <input name="email" type="text" class="input" /> 
            </div> 
            <div class="desktop-2 tablet-1 mobile-full"> 
                <label>Estado:</label> 
                <select name="estado" class="input"> <option value="1">RJ</option> <option value="2">SP</option> </select> 
            </div> 
            <div class="all-full"> 
                <label>Mensagem:</label> 
                <textarea name="mensagem" type="text" class="input"></textarea> 
            </div> 
            <div class="all-full"> 
                <div class="centered"> 
                    <button class="button-primary">Enviar</button> 
                </div> 
            </div> 
        </form> 
        <script src="js/jquery/jquery-1.11.1.min.js"></script> 
        <script src="js/jquery.slicknav.min.js"></script> 
        <script type="text/javascript" src="js/validate/jquery.validate.js"></script> 
        <script type="text/javascript" src="js/validate/jquery.maskedinput.js"></script> 
        <script type="text/javascript">
					$(document).ready(function(){
						var curForm = $("#myForm");

						curForm.validate({
							rules: {
								nome: {required: true, minlength: 4},
								email: {required: true, email: true},
								mensagem: {required: true},
							},
							messages: {
								nome: {required: "Favor preencher seu nome completo", minlength: "O nome deve ter pelo menos 4 caracteres"},
								email: {required: "Favor preencher um e-mail", email:"Favor preencher com um e-mail válido"},
								mensagem: "Favor preencher a mensagem",
							}, submitHandler: function(form){
								$(".warning .error").hide();
								$(".warning .success").hide();
								$.ajax({
									type: "POST",
									dataType: "json",
									url: curForm.attr("action"),
									data: curForm.serialize(),
									success: function(data){
										// success handling here
										$(".warning .success").show();
										curForm[0].reset();
									}

								}).fail(function(data){
									$(".warning .error").show();
									// fail handling here
								});
								return false;
							}
						});
					});
				</script> 
    </div> 
</article>